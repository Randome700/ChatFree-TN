// server.js
// Anonymous 1-on-1 DM platform — backend
// Node.js + Express + Socket.io, fully in-memory (no database required).

const express = require("express");
const http = require("http");
const cors = require("cors");
const { Server } = require("socket.io");

const app = express();

// --- CORS setup -------------------------------------------------------
// Allow GitHub Pages (or any origin) to connect. Tighten this in production
// by replacing "*" with your actual GitHub Pages URL, e.g.
// "https://yourusername.github.io"
app.use(cors({ origin: "*" }));
app.use(express.json());

const server = http.createServer(app);
const io = new Server(server, {
  cors: {
    origin: "*",
    methods: ["GET", "POST"],
  },
});

// --- In-memory state ----------------------------------------------------
// activeUsers: { [socketId]: { socketId, age, sex } }
const activeUsers = {};

// --- Health check (also keeps Render/Koyeb free instances easy to ping) ---
app.get("/", (req, res) => {
  res.json({
    status: "ok",
    service: "anon-chat-backend",
    onlineUsers: Object.keys(activeUsers).length,
  });
});

// Track which two socket IDs are currently "paired" in a conversation so we
// can notify the remaining party if the other one disconnects.
// conversations: { [socketId]: Set of socketIds they've messaged with }
const conversations = {};

// --- Anti-spam "cold outreach" limit -------------------------------------
// Rule: you may send up to MAX_COLD_MESSAGES to someone who has never replied
// to you. Once they send you anything back, the gate unlocks permanently for
// that direction (you can message them freely from then on).
// messageGates[senderId][targetId] = { count, unlocked }
const MAX_COLD_MESSAGES = 2;
const messageGates = {};

function gateState(senderId, targetId) {
  if (!messageGates[senderId]) messageGates[senderId] = {};
  if (!messageGates[senderId][targetId]) {
    messageGates[senderId][targetId] = { count: 0, unlocked: false };
  }
  return messageGates[senderId][targetId];
}

function canSend(senderId, targetId) {
  const state = gateState(senderId, targetId);
  return state.unlocked || state.count < MAX_COLD_MESSAGES;
}

function recordSend(senderId, targetId) {
  const state = gateState(senderId, targetId);
  if (!state.unlocked) state.count += 1;
}

// Sending FROM senderId TO targetId counts as senderId having "responded",
// which unlocks targetId's ability to message senderId freely from now on.
function unlockReverseGate(senderId, targetId) {
  const state = gateState(targetId, senderId);
  state.unlocked = true;
}

function remainingColdMessages(senderId, targetId) {
  const state = gateState(senderId, targetId);
  if (state.unlocked) return null; // unlimited
  return Math.max(0, MAX_COLD_MESSAGES - state.count);
}

function clearGatesFor(socketId) {
  delete messageGates[socketId];
  Object.values(messageGates).forEach((targets) => {
    delete targets[socketId];
  });
}

function addConversationLink(a, b) {
  if (!conversations[a]) conversations[a] = new Set();
  if (!conversations[b]) conversations[b] = new Set();
  conversations[a].add(b);
  conversations[b].add(a);
}

function removeUserEverywhere(socketId) {
  delete activeUsers[socketId];

  const partners = conversations[socketId];
  if (partners) {
    partners.forEach((partnerId) => {
      if (conversations[partnerId]) {
        conversations[partnerId].delete(socketId);
      }
      // Notify the partner that this user has left, if they're still online.
      io.to(partnerId).emit("partner_disconnected", { socketId });
    });
  }
  delete conversations[socketId];
  clearGatesFor(socketId);
}

// Basic HTML-escaping to prevent stored/reflected XSS via chat messages.
function escapeHtml(str) {
  return String(str)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

function publicUserList() {
  return Object.values(activeUsers).map((u) => ({
    socketId: u.socketId,
    age: u.age,
    sex: u.sex,
  }));
}

function broadcastUserList() {
  io.emit("update_user_list", publicUserList());
}

io.on("connection", (socket) => {
  // --- join: register a new anonymous user ------------------------------
  socket.on("join", (payload) => {
    const age = Number(payload && payload.age);
    const sex = payload && String(payload.sex || "").toLowerCase();

    // Server-side validation, never trust the client.
    if (!Number.isInteger(age) || age < 18 || age > 99) {
      socket.emit("join_error", { message: "Age must be between 18 and 99." });
      return;
    }
    if (sex !== "male" && sex !== "female") {
      socket.emit("join_error", { message: "Sex must be 'male' or 'female'." });
      return;
    }

    activeUsers[socket.id] = { socketId: socket.id, age, sex };

    socket.emit("joined", { socketId: socket.id, age, sex });
    broadcastUserList();
  });

  // --- private_message: relay a DM to a single target socket ------------
  socket.on("private_message", ({ targetSocketId, text }) => {
    const sender = activeUsers[socket.id];
    if (!sender) return; // must have joined first
    if (!targetSocketId || !activeUsers[targetSocketId]) {
      socket.emit("message_error", { message: "That user is no longer online." });
      return;
    }

    if (!canSend(socket.id, targetSocketId)) {
      socket.emit("message_blocked", {
        targetSocketId,
        message:
          "You've sent enough messages without a reply. Wait for them to respond before sending more.",
      });
      return;
    }

    const clean = escapeHtml(String(text || "")).slice(0, 2000);
    if (!clean.trim()) return;

    addConversationLink(socket.id, targetSocketId);
    recordSend(socket.id, targetSocketId);
    unlockReverseGate(socket.id, targetSocketId);

    const messageId = `${socket.id}-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;

    const messagePayload = {
      messageId,
      fromSocketId: socket.id,
      fromAge: sender.age,
      fromSex: sender.sex,
      text: clean,
      timestamp: Date.now(),
    };

    io.to(targetSocketId).emit("private_message", messagePayload);

    // Echo back to sender so their own UI can render it (with same shape),
    // including how many "cold" messages they have left with this person.
    socket.emit("private_message_sent", {
      ...messagePayload,
      remaining: remainingColdMessages(socket.id, targetSocketId),
    });
  });

  // --- typing indicator ----------------------------------------------------
  socket.on("typing", ({ targetSocketId, isTyping }) => {
    if (!targetSocketId || !activeUsers[targetSocketId]) return;
    io.to(targetSocketId).emit("typing", {
      fromSocketId: socket.id,
      isTyping: Boolean(isTyping),
    });
  });

  // --- read receipts ---------------------------------------------------------
  // Client tells us "I've now seen everything from peerSocketId" — we relay
  // that to the peer so their sent messages flip to a 'seen' checkmark.
  socket.on("mark_seen", ({ peerSocketId }) => {
    if (!peerSocketId || !activeUsers[peerSocketId]) return;
    io.to(peerSocketId).emit("seen_by", { socketId: socket.id, at: Date.now() });
  });

  // --- disconnect ---------------------------------------------------------
  socket.on("disconnect", () => {
    removeUserEverywhere(socket.id);
    broadcastUserList();
  });
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
  console.log(`Anon chat backend listening on port ${PORT}`);
});
