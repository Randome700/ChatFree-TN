# Deployment Guide — Wavelength (Anonymous 1-on-1 Chat)

This gets you a $0/month deployment: backend on Render's free tier, frontend on GitHub Pages.

## Project layout
```
anon-chat/
├── backend/
│   ├── server.js
│   └── package.json
├── frontend/
│   ├── index.html
│   ├── style.css
│   └── app.js
└── DEPLOYMENT_GUIDE.md
```

---

## Part 1 — Push the code to GitHub

1. Create a new GitHub repository, e.g. `wavelength-chat`.
2. From your local `anon-chat` folder:
   ```bash
   git init
   git add .
   git commit -m "Initial commit: anonymous 1-on-1 chat platform"
   git branch -M main
   git remote add origin https://github.com/<your-username>/wavelength-chat.git
   git push -u origin main
   ```

---

## Part 2 — Deploy the backend on Render (free tier)

1. Go to [render.com](https://render.com) and sign in with GitHub.
2. Click **New +** → **Web Service**.
3. Select your `wavelength-chat` repo.
4. Configure:
   - **Root Directory**: `backend`
   - **Environment**: `Node`
   - **Build Command**: `npm install`
   - **Start Command**: `npm start`
   - **Instance Type**: Free
5. Click **Create Web Service**. Render will build and deploy it.
6. Once live, copy your backend URL, e.g.:
   ```
   https://wavelength-chat-backend.onrender.com
   ```
7. Visit that URL in a browser — you should see a small JSON status response confirming the server is running.

> **Free-tier note:** Render's free web services spin down after ~15 minutes of inactivity and take ~30–60 seconds to wake back up on the next request. This is normal for a $0 setup; consider a lightweight uptime pinger (e.g. UptimeRobot, free) hitting the `/` route every 10 minutes if you want to minimize cold starts. Koyeb and Railway have similar free-tier characteristics — instructions above apply nearly identically to either.

---

## Part 3 — Point the frontend at your backend

1. Open `frontend/app.js`.
2. Change:
   ```js
   const BACKEND_URL = "http://localhost:3000";
   ```
   to your live Render URL:
   ```js
   const BACKEND_URL = "https://wavelength-chat-backend.onrender.com";
   ```
3. Commit and push this change.

---

## Part 4 — Deploy the frontend on GitHub Pages

1. In your GitHub repo, go to **Settings** → **Pages**.
2. Under **Build and deployment**:
   - **Source**: Deploy from a branch
   - **Branch**: `main`, folder: `/frontend`

   (GitHub Pages requires the folder to be `/` or `/docs` in some plans — if `/frontend` isn't selectable, either move the frontend files to a `docs/` folder, or use a separate repo containing only the frontend files at its root.)
3. Save. GitHub will publish your site at:
   ```
   https://<your-username>.github.io/wavelength-chat/
   ```
4. Visit that URL — the entry modal should appear, and submitting it should connect to your Render backend.

---

## Part 5 — Tighten CORS (recommended before sharing publicly)

In `backend/server.js`, replace the wildcard with your actual Pages URL once you know it:

```js
app.use(cors({ origin: "https://<your-username>.github.io" }));
// ...
const io = new Server(server, {
  cors: {
    origin: "https://<your-username>.github.io",
    methods: ["GET", "POST"],
  },
});
```

Commit and push — Render will auto-redeploy on every push to `main`.

---

## Local testing (before deploying)

```bash
# Terminal 1 — backend
cd backend
npm install
npm start
# server runs on http://localhost:3000

# Terminal 2 — frontend
cd frontend
npx serve .
# or just open index.html directly in a browser
```

Open two separate browser windows (or one normal + one incognito) pointed at the frontend to simulate two different anonymous users chatting with each other.

---

## Operational notes worth knowing before you launch this publicly

- **State is in-memory only.** Every Render free-tier restart (including the sleep/wake cycle) wipes the online user list and all active conversations. That's expected for a $0 architecture — just don't advertise message history as persistent.
- **No moderation or reporting exists yet.** For a public anonymous chat app with no accounts, consider adding at minimum: a report/block button, a message rate limiter (to blunt spam/harassment), and a basic profanity or abuse filter before opening it to real users. `socket.io`'s per-socket connection lets you rate-limit with a simple timestamp check in the `private_message` handler.
- **Age is self-reported and unverified**, as is common for this kind of lightweight app — it filters casual browsing, not a safeguard you should rely on. If you plan to operate this for real users rather than as a portfolio/demo project, budget time to add real age verification and a clear terms-of-service/acceptable-use policy, and check what your hosting providers' and payment processors' policies require for anonymous chat products before launch.
